const vscode = require("vscode");
const path = require("path");

function activate(context) {
  console.log("✅ sdev RUN extension activated");

  const runCommand = vscode.commands.registerCommand("sdev.run", () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage("No file open");
      return;
    }

    const filePath = editor.document.fileName;

    const terminal = vscode.window.createTerminal("sdev");
    terminal.show();

    terminal.sendText(`sdev.exe "${filePath}"`);
  });

  context.subscriptions.push(runCommand);
}

function deactivate() {}

module.exports = { activate, deactivate };
