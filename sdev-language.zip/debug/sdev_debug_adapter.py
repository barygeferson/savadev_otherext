import sys
import json

def read_message():
    headers = {}
    while True:
        line = sys.stdin.readline()
        if line == "\r\n" or line == "\n":
            break
        key, value = line.split(":", 1)
        headers[key.strip()] = value.strip()

    length = int(headers.get("Content-Length", 0))
    if length == 0:
        return None

    return json.loads(sys.stdin.read(length))

def send_message(payload):
    body = json.dumps(payload)
    sys.stdout.write(f"Content-Length: {len(body)}\r\n\r\n{body}")
    sys.stdout.flush()

def main():
    while True:
        req = read_message()
        if not req:
            break

        cmd = req.get("command")

        if cmd == "initialize":
            send_message({
                "type": "response",
                "request_seq": req["seq"],
                "success": True,
                "command": "initialize",
                "body": {
                    "supportsConfigurationDoneRequest": True
                }
            })

            # 🔴 THIS EVENT IS REQUIRED
            send_message({
                "type": "event",
                "event": "initialized"
            })

        elif cmd == "configurationDone":
            send_message({
                "type": "response",
                "request_seq": req["seq"],
                "success": True,
                "command": "configurationDone"
            })

        elif cmd == "launch":
            program = req["arguments"]["program"]

            # ✅ Ask VS Code to open a terminal
            send_message({
                "type": "request",
                "command": "runInTerminal",
                "arguments": {
                    "kind": "integrated",
                    "title": "sdev",
                    "args": [
                        "C:\\sdev\\bin\\sdev.exe",
                        program
                    ]
                }
            })

            send_message({
                "type": "response",
                "request_seq": req["seq"],
                "success": True,
                "command": "launch"
            })

        elif cmd == "disconnect":
            break

if __name__ == "__main__":
    main()
