sdev full extension + debug adapter (Option C)
==============================================

Contents:
- VS Code extension with debug adapter (debugAdapter.js)
- sdev_debug.py : an enhanced interpreter stub that implements a simple TCP JSON debug protocol.
  Path expected in configs: C:\\sdev\\bin\\sdev.py (or change in settings)
- Instructions: install dependencies with `npm install` inside the extension folder.

How to use:
1. Unzip into %USERPROFILE%\\.vscode\\extensions\\sdev-full
2. In the extension folder, run `npm install` to install debug adapter dependencies.
3. Ensure your interpreter (sdev_debug.py) is at C:\\sdev\\bin\\sdev.py or update the launch configuration.
4. Open a .sdev file, press F5 to start debugging. The adapter will spawn the interpreter with --debug-port and connect to it.

Limitations:
- The provided sdev_debug.py is a minimal stub that demonstrates the debug protocol. Integrate it with your full interpreter to support full variable inspection and precise stepping.
- The debug adapter expects the interpreter to speak the simple JSON protocol over TCP (newline-separated JSON messages).
