\
    # sdev interpreter with simple debug server
    import socket, threading, json, sys, time, argparse
    from pathlib import Path

    # This is a very small wrapper around a simple executor that steps through lines.
    # For full language semantics integrate with your existing interpreter. This MVP interpreter
    # will execute a file line-by-line and report stops to a debugger client.
    class DebugServer:
        def __init__(self, port):
            self.port = port
            self.sock = None
            self.conn = None
            self.addr = None
            self.breakpoints = {}  # path -> set(lines)
            self._lock = threading.Lock()
            self._paused = threading.Event()
            self._paused.set()  # start unpaused
            self._last_stop = None
            self._eval_result = None

        def start(self):
            t = threading.Thread(target=self._run, daemon=True)
            t.start()

        def _run(self):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('127.0.0.1', self.port))
            s.listen(1)
            print(f"[sdev-debug] waiting for debugger connection on port {self.port}", file=sys.stderr)
            conn, addr = s.accept()
            self.conn = conn
            self.addr = addr
            print(f"[sdev-debug] debugger connected {addr}", file=sys.stderr)
            buf = ''
            while True:
                data = conn.recv(4096)
                if not data:
                    break
                buf += data.decode('utf8')
                while '\\n' in buf:
                    line, buf = buf.split('\\n',1)
                    if not line.strip(): continue
                    try:
                        msg = json.loads(line)
                        self._handle(msg)
                    except Exception as e:
                        print('[sdev-debug] invalid json', e, file=sys.stderr)

        def _handle(self, msg):
            cmd = msg.get('command')
            if cmd == 'setBreakpoints':
                path = msg.get('path')
                lines = msg.get('lines',[])
                self.breakpoints[path] = set(lines)
                self._send({'event':'breakpointsSet','path':path,'lines':lines})
            elif cmd == 'continue':
                self._paused.set()
            elif cmd == 'stepOver' or cmd == 'stepIn':
                # signal to run one step
                self._last_stop = 'step'
                self._paused.set()
            elif cmd == 'evaluate':
                expr = msg.get('expr')
                # naive eval in global namespace (unsafe)
                try:
                    r = eval(expr, globals(), globals())
                    self._send({'event':'evaluate','result':repr(r)})
                except Exception as e:
                    self._send({'event':'evaluate','result':f'Error: {e}'})

        def _send(self, obj):
            try:
                if self.conn:
                    self.conn.sendall((json.dumps(obj)+'\\n').encode('utf8'))
            except Exception as e:
                print('[sdev-debug] send failed', e, file=sys.stderr)

        def should_pause(self, path, lineno):
            lines = self.breakpoints.get(path, set())
            return lineno in lines

        def notify_stop(self, path, lineno):
            self._paused.clear()
            self._send({'event':'stopped','path':path,'line':lineno})
            # wait until resumed
            self._paused.wait()

    def run_file(path, dbg: DebugServer=None):
        # simplistic line-by-line executor: executes Python translation of sdev lines
        lines = Path(path).read_text().splitlines()
        glob = {}
        for idx, raw in enumerate(lines, start=1):
            line = raw.strip()
            if dbg and dbg.should_pause(path, idx):
                dbg.notify_stop(path, idx)
            # simplistic implementation: support print via speak(...) -> Python print
            if line.startswith('speak(') and line.endswith(')'):
                expr = line[len('speak('):-1]
                try:
                    val = eval(expr, glob, glob)
                    print(val)
                except Exception as e:
                    print('Error evaluating:', e, file=sys.stderr)
            # very small subset: assignment "forge x be 10" or "x be 10"
            elif line.startswith('forge '):
                try:
                    rest = line[len('forge '):]
                    if ' be ' in rest:
                        name, expr = rest.split(' be ',1)
                        glob[name.strip()] = eval(expr, glob, glob)
                except Exception as e:
                    print('assign error', e, file=sys.stderr)
            elif ' be ' in line:
                try:
                    name, expr = line.split(' be ',1)
                    name = name.strip()
                    if dbg and dbg.should_pause(path, idx):
                        dbg.notify_stop(path, idx)
                    glob[name] = eval(expr, glob, glob)
                except Exception as e:
                    print('assign error', e, file=sys.stderr)
            else:
                # ignore
                pass

    def main():
        parser = argparse.ArgumentParser()
        parser.add_argument('file', nargs='?', help='sdev file to run')
        parser.add_argument('--debug-port', type=int, default=5678, help='debug server port')
        args = parser.parse_args()
        dbg = DebugServer(args.debug_port)
        dbg.start()
        if args.file:
            run_file(args.file, dbg)
        # send terminated event
        dbg._send({'event':'terminated'})

    if __name__ == '__main__':
        main()
