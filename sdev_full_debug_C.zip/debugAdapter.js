\
    const { DebugSession, InitializedEvent, StoppedEvent, Thread, StackFrame, Scope, Source, Handles, TerminatedEvent, ContinuedEvent } = require('vscode-debugadapter');
    const { DebugProtocol } = require('vscode-debugprotocol');
    const net = require('net');
    const child_process = require('child_process');
    const { basename } = require('path');
    const fs = require('fs');

    class SdevDebugSession extends DebugSession {
        constructor() {
            super();
            this._client = null;
            this._socket = null;
            this._seq = 1;
            this._breakpoints = {}; // {source:path: [lines]}
            this.setDebuggerLinesStartAt1(true);
            this.setDebuggerColumnsStartAt1(true);
            this._threads = [{id:1,name:"Main Thread"}];
            this._variables = new Handles();
        }

        initializeRequest(response, args) {
            response.body = response.body || {};
            response.body.supportsConfigurationDoneRequest = true;
            response.body.supportsEvaluateForHovers = true;
            this.sendResponse(response);
            this.sendEvent(new InitializedEvent());
        }

        launchRequest(response, args) {
            // start interpreter in --debug mode which will open a TCP server and wait for connection
            const program = args.program;
            const port = args.port || 5678;
            const interpreterArgs = args.args || [];
            const fullArgs = ['--debug-port', String(port)].concat(interpreterArgs);
            // spawn interpreter
            const proc = child_process.spawn('python', [program].concat(fullArgs), {stdio:['pipe','pipe','pipe']});
            proc.stdout.on('data', (d)=> console.log('[sdev stdout] '+d.toString()));
            proc.stderr.on('data', (d)=> console.error('[sdev stderr] '+d.toString()));
            this._proc = proc;

            // connect to interpreter debug server TCP
            const tryConnect = ()=> {
                const sock = net.createConnection(port, '127.0.0.1', ()=> {
                    this._socket = sock;
                    sock.setEncoding('utf8');
                    sock.on('data', (data)=> this._onSocketData(data));
                    sock.on('close', ()=> this.sendEvent(new TerminatedEvent()));
                    this.sendResponse(response);
                });
                sock.on('error',(err)=> {
                    // retry until connected
                    setTimeout(tryConnect, 200);
                });
            };
            tryConnect();
        }

        _onSocketData(data) {
            // data may contain multiple JSON lines
            const lines = data.toString().split('\n').filter(l=>l.trim());
            for (const line of lines) {
                try {
                    const msg = JSON.parse(line);
                    this._handleMessage(msg);
                } catch(e) {
                    console.error('Invalid JSON from interpreter', e, line);
                }
            }
        }

        _handleMessage(msg) {
            if (msg.event === 'stopped') {
                // send stopped event with reason 'breakpoint'
                this.sendEvent(new StoppedEvent('breakpoint', 1));
            } else if (msg.event === 'output') {
                // send output event as continued then output - simplified: emit to console
                this.sendEvent(new ContinuedEvent(1));
            } else if (msg.event === 'terminated') {
                this.sendEvent(new TerminatedEvent());
            }
        }

        setBreakPointsRequest(response, args) {
            const path = args.source.path;
            const lines = args.lines || [];
            // store breakpoints and send to interpreter
            this._breakpoints[path] = lines;
            this._send({command:'setBreakpoints', path:path, lines:lines});
            response.body = {breakpoints: lines.map(l=>({verified:true, line:l}))};
            this.sendResponse(response);
        }

        threadsRequest(response) {
            response.body = {threads: this._threads};
            this.sendResponse(response);
        }

        stackTraceRequest(response, args) {
            // ask interpreter for stack
            // simplified: return single frame at current file
            const frames = [ new StackFrame(1, "main", new Source(basename('file'), args.startFrame || ''), 1, 1) ];
            response.body = {stackFrames: frames, totalFrames: frames.length};
            this.sendResponse(response);
        }

        scopesRequest(response, args) {
            const scopes = [ new Scope("Locals", this._variables.create("locals"), false) ];
            response.body = {scopes: scopes};
            this.sendResponse(response);
        }

        continueRequest(response, args) {
            this._send({command:'continue'});
            this.sendResponse(response);
        }

        nextRequest(response, args) {
            this._send({command:'stepOver'});
            this.sendResponse(response);
        }

        stepInRequest(response, args) {
            this._send({command:'stepIn'});
            this.sendResponse(response);
        }

        evaluateRequest(response, args) {
            const expr = args.expression;
            // ask interpreter to evaluate expression in current frame
            this._send({command:'evaluate', expr: expr});
            // naive: respond immediately with placeholder
            response.body = {result: "<evaluation pending>", variablesReference: 0};
            this.sendResponse(response);
        }

        _send(obj) {
            if (!this._socket) return;
            try {
                this._socket.write(JSON.stringify(obj) + "\\n");
            } catch(e) {
                console.error('Failed to send to interpreter', e);
            }
        }
    }

    DebugSession.run(SdevDebugSession);
