const vscode = require("vscode");
const { execFile } = require("child_process");

function getSdevExe() {
  return "C:\\sdev\\bin\\sdev.exe";
}

function runSdev(debug = false) {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showErrorMessage("No active sdev file.");
    return;
  }

  const file = editor.document.fileName;
  const exe = getSdevExe();
  const args = debug ? ["--debug", file] : [file];

  execFile(exe, args, (err, stdout, stderr) => {
    if (err) {
      vscode.window.showErrorMessage(stderr || err.message);
      return;
    }
    if (stdout) vscode.window.showInformationMessage(stdout);
  });
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand("sdev.run", () => runSdev(false)),
    vscode.commands.registerCommand("sdev.debug", () => runSdev(true))
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
