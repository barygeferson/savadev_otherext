const vscode = require('vscode');
const path = require('path');

function activate(context) {
    let runCommand = vscode.commands.registerCommand('sdev.runFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage("Open a .sdev file first.");
            return;
        }

        const filePath = editor.document.fileName;
        const config = vscode.workspace.getConfiguration("sdev");
        const interpreter = config.get("interpreterPath");

        const terminal = vscode.window.createTerminal("sdev");
        terminal.show();
        terminal.sendText(`python "${interpreter}" "${filePath}"`);
    });

    context.subscriptions.push(runCommand);
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
};
